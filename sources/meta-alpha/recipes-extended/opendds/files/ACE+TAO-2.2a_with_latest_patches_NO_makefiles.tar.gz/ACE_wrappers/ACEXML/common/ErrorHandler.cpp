// $Id$

#include "ErrorHandler.h"

ACEXML_ErrorHandler::~ACEXML_ErrorHandler (void)
{
}
