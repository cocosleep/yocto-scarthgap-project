// $Id$

#include "EntityResolver.h"

ACEXML_EntityResolver::~ACEXML_EntityResolver (void)
{
}
