// $Id$

int foo()
{
  return 42;
}
