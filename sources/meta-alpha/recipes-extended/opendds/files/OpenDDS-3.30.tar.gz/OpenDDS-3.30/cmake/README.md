# Config Package for CMake Integration

Please take a look at the [CMake documentation](https://opendds.readthedocs.io/en/latest-release/devguide/building/cmake.html) for further details.
