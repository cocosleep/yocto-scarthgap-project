/*
 *
 *
 * Distributed under the OpenDDS License.
 * See: http://www.opendds.org/license.html
 */

#ifndef OPENDDS_DCPS_DDSDCPS_PCH_H
#define OPENDDS_DCPS_DDSDCPS_PCH_H

#ifdef USING_PCH

#include "dds/DdsDcpsDomainC.h"
#include "tao/ORB_Core.h"

#endif
#endif
