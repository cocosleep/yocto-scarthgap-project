// This file is a placeholder to prevent inclusion of TAO's PolicyS.h
// which pulls in the PortableServer library.

#ifndef OPENDDS_CORBA_TAO_POLICYS_H
#define OPENDDS_CORBA_TAO_POLICYS_H
#endif // OPENDDS_CORBA_TAO_POLICYS_H
